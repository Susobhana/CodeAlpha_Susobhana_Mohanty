# Calculator Studio — Exact Background + Vibrant UI

This build uses the user's supplied artwork as the exact, byte-for-byte page background:
`assets/calculator-background.png`

The foreground UI has been redesigned with colorful glassmorphism, gradients, depth, glow, and richer component styling. The background artwork itself is not regenerated, recolored, blurred, tinted, or replaced.

All calculator functionality from the source project is preserved.
