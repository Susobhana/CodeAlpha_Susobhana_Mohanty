This project uses reliable Unsplash image URLs so it works immediately when opened in a browser with internet access.

To use local photography instead, place files in the matching category folders and replace the relevant `src` URL values in ../script.js. Keep every image's `alt`, title and description updated to accurately describe the replacement photograph.
