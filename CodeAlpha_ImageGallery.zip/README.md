# FRAME / 01 — Digital Photography Archive

A premium, immersive digital photography archive built with semantic HTML, CSS and Vanilla JavaScript. The V4 experience focuses on visual discovery, editorial storytelling, local curation and accessible interaction rather than audience-specific presentation.

## Highlights
- Cinematic hero and editorial archive
- Visual discovery by mood, tone, time, weather, environment and photography type
- Color Stories and palette exploration
- Smart filters, search, sorting and active filter states
- Surprise Me, Frame of the Day and deterministic visual journeys
- Enhanced collections, exhibitions and story chapters
- Immersive V4 image viewer with navigation, zoom, swipe, fullscreen, sharing and related frames
- Deterministic Explore Similar recommendations
- Local Favorites, Recently Viewed and private Moodboard
- Two-frame Compare mode
- Editorial, Grid, Compact, Focus and Contact Sheet concepts
- Command palette and keyboard shortcuts
- Dark/light themes, low-bandwidth behavior and reduced-motion support
- Lazy loading, image preloading and progressive rendering
- Responsive desktop, tablet and mobile layouts
- Accessibility-focused focus states, labels and keyboard behavior
- Archive statistics, Visual DNA and Interaction Lab

## Run
Open `index.html` directly in a modern browser. No framework, package manager, build step, backend or database is required.

## Privacy
Favorites, recent frames, moodboard, comparison state, theme and local preferences are stored in the browser with `localStorage`. No browsing history is uploaded by this project.

## Image data
The archive currently contains the existing project image records and their remote image sources. Metadata such as mood, environment, weather and time-of-day is derived deterministically for the interface where those fields were not present in the original dataset. The project intentionally does not fabricate photographer credentials, awards, reviews, camera metadata or engagement metrics.

## V4 files
- `index.html` — page structure
- `style.css` — original/core design system
- `script.js` — existing archive state and functionality
- `v4.css` — V4 visual system
- `v4.js` — V4 interaction and discovery layer

## Known limitations
- Remote image availability depends on the image host/network.
- Browser fullscreen and Web Share behavior varies by browser.
- The local Moodboard and Favorites are intentionally browser-local.


## V4.1 expansion
- Expanded the archive from 210 to 330 records (120 additional frames).
- Fixed V4 palette discovery by exposing the image dataset to the V4 layer and normalizing palette metadata before filtering.
- Added year browsing, Focus Mode, Auto Tour, Saved Frames shortcut, Newest/Shuffle controls, and Copy Details/Open Image actions in the immersive viewer.
- Palette counts are computed from the same metadata used by the gallery filter, so the color story buttons stay consistent with the archive.
